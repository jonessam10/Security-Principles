
package com.securitytest;

import java.io.FileWriter;
import java.io.IOException;

public class ResultLogger {
    public static void log(String prompt, String response) {
        try(FileWriter writer = new FileWriter("results.txt", true)) {
            writer.write("\n===== PROMPT =====\n" + prompt +
                         "\n----- RESPONSE -----\n" + response + "\n");
        } catch(IOException e){
            e.printStackTrace();
        }
    }
}
