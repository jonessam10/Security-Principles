
package com.securitytest;

import java.nio.file.*;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        List<TestCase> tests = TestCase.loadFromJson("test-prompts.json");

        for (TestCase test : tests) {
            String response = OpenAIClient.sendPrompt(test.prompt);
            ResultLogger.log(test.prompt, response);
            System.out.println("\n===== TEST PROMPT =====");
            System.out.println(test.prompt);
            System.out.println("----- RESPONSE -----");
            System.out.println(response);
        }
        System.out.println("\nResults saved to results.txt");
    }
}
