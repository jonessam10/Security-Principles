
package com.securitytest;

import java.io.*;
import java.util.*;
import org.json.*;

public class TestCase {
    public String prompt;

    public static List<TestCase> loadFromJson(String filePath) throws Exception {
        String json = new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(filePath)));
        JSONArray arr = new JSONArray(json);
        List<TestCase> list = new ArrayList<>();

        for(int i=0;i<arr.length();i++){
            TestCase t = new TestCase();
            t.prompt = arr.getJSONObject(i).getString("prompt");
            list.add(t);
        }
        return list;
    }
}
