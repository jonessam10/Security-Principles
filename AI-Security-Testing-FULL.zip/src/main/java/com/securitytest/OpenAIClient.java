
package com.securitytest;

import okhttp3.*;
import org.json.*;

public class OpenAIClient {
    private static final String API_KEY = "YOUR_API_KEY";
    private static final String URL = "https://api.openai.com/v1/chat/completions";

    public static String sendPrompt(String prompt) throws Exception {
        OkHttpClient client = new OkHttpClient();

        JSONObject json = new JSONObject()
            .put("model", "gpt-4o-mini")
            .put("messages", new JSONArray()
               .put(new JSONObject().put("role", "user").put("content", prompt))
        );

        RequestBody body = RequestBody.create(json.toString(), MediaType.get("application/json"));
        Request request = new Request.Builder().url(URL)
                .addHeader("Authorization", "Bearer " + API_KEY).post(body).build();

        Response response = client.newCall(request).execute();
        return response.body().string();
    }
}
