
# AI Security Testing Java Project

This program sends security-related prompts to an AI model and logs responses to evaluate safety behavior.

## Run Steps
1. Add your OpenAI API key → `OpenAIClient.java`
2. Run using Maven or an IDE
3. Results are saved in `results.txt`

